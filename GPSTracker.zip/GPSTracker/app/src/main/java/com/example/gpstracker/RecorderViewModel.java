package com.example.gpstracker;

import androidx.lifecycle.ViewModel;

public class RecorderViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
